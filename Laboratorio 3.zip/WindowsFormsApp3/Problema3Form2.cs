﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3
{
    public partial class problema3Form2 : Form
    {
        public problema3Form2()
        {
            InitializeComponent();
        }
    }
}
